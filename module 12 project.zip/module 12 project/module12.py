import random

rock='''   ''' 

paper='''  '''
scissors='''  '''

list1=[rock,paper,scissors]
t=1
while(t>0):
  n=(input("What do you choose? Type Rock or paper or Scissors and Quit to exit. "))
  if n.lower()!="rock" and n.lower()!="paper" and n.lower()!="scissors" and n.lower()!="quit":
    print("Enter Correct Choice!")
    continue
  elif(n.lower()=="quit"):
      print("Thanks for Playing, Hope you enjoyed it.")
      exit()
  else:
    print("You Chose: ")
    if(n.lower()=="rock"):
      print(list1[0])
      x=int(0)
    if(n.lower()=="paper"):
      print(list1[1])
      x+=1
    if(n.lower()=="scissors"):
      print(list1[2])
      x+=2
  
  print("Computer Chose: ")
  m=random.randint(0,2)
  print(list1[m])

  if m==x:
    print("It's a tie.")
  elif x==0 and m==2 or x==1 and m==0 or x==2 and m==1:
    print("Congrats! you won!")
  else:
    print("You loose,cheer up and try again\n")