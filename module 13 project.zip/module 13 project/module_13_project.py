import requests

pokemon = input("Which pokemon do you want to find? ")
pokemon = pokemon.lower()

url = f"https://pokeapi.co/api/v2/pokemon/{pokemon}"

req = requests.get(url)

data = req.json()

print(f"Name: \t{data['name']}")

print(f"Abilities:")
for ability in data['abilities']:
    print("\t",ability['ability']['name'])

print(f"Items Held:")
for item in data['held_items']:
    print("\t",item['item']['name'])

print(f"Moves:")
for move in data['moves']:
    print("\t",move['move']['name'])
